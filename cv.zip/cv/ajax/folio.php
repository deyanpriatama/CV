<?php
$count = $_POST['count'];
if($count == 1){
    echo '<div class="col-lg-4 folio_effect mix graphic">
            <div class="folio_item">
                <a href="single_folio.html" class="folio_item_thumbs">
                    <div class="folio_stack">
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_img_holder">
                            <img class="folio_img" src="assets/images/folio/7.jpg" alt="Image">
                        </div>
                    </div>
                </a>
                <div class="folio_content">
                    <h3 class="folio_title"><a href="single_folio.html">Design Structure</a></h3>
                    <p class="folio_cat"><a href="portfolio.html">Graphic</a></p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 folio_effect mix app">
            <div class="folio_item">
                <a href="single_folio.html" class="folio_item_thumbs">
                    <div class="folio_stack">
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_img_holder">
                            <img class="folio_img" src="assets/images/folio/8.jpg" alt="Image">
                        </div>
                    </div>
                </a>
                <div class="folio_content">
                    <h3 class="folio_title"><a href="single_folio.html">Animation App</a></h3>
                    <p class="folio_cat"><a href="portfolio.html">App</a></p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 folio_effect mix illustrtopm">
            <div class="folio_item">
                <a href="single_folio.html" class="folio_item_thumbs">
                    <div class="folio_stack">
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_img_holder">
                            <img class="folio_img" src="assets/images/folio/9.jpg" alt="Image">
                        </div>
                    </div>
                </a>
                <div class="folio_content">
                    <h3 class="folio_title"><a href="single_folio.html">Super Hero Illustration</a></h3>
                    <p class="folio_cat"><a href="portfolio.html">Illustration</a></p>
                </div>
            </div>
        </div>';
}elseif($count == 2){
    echo '<div class="col-lg-4 folio_effect mix dev">
            <div class="folio_item">
                <a href="single_folio.html" class="folio_item_thumbs">
                    <div class="folio_stack">
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_img_holder">
                            <img class="folio_img" src="assets/images/folio/10.jpg" alt="Image">
                        </div>
                    </div>
                </a>
                <div class="folio_content">
                    <h3 class="folio_title"><a href="single_folio.html">Online Software</a></h3>
                    <p class="folio_cat"><a href="portfolio.html">Development</a></p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 folio_effect mix graphic">
            <div class="folio_item">
                <a href="single_folio.html" class="folio_item_thumbs">
                    <div class="folio_stack">
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_img_holder">
                            <img class="folio_img" src="assets/images/folio/11.jpg" alt="Image">
                        </div>
                    </div>
                </a>
                <div class="folio_content">
                    <h3 class="folio_title"><a href="single_folio.html">Info Graphic Design</a></h3>
                    <p class="folio_cat"><a href="portfolio.html">Graphic</a></p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 folio_effect mix illustrtopm">
            <div class="folio_item">
                <a href="single_folio.html" class="folio_item_thumbs">
                    <div class="folio_stack">
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_decoration"></div>
                        <div class="folio_img_holder">
                            <img class="folio_img" src="assets/images/folio/12.jpg" alt="Image">
                        </div>
                    </div>
                </a>
                <div class="folio_content">
                    <h3 class="folio_title"><a href="single_folio.html">Abstract Elements</a></h3>
                    <p class="folio_cat"><a href="portfolio.html">UI/UX</a></p>
                </div>
            </div>
        </div>';
}
exit();